# odoo-sample-module
Extending https://github.com/vyngt/odoo-sample-app app

```git clone https://github.com/vyngt/odoo-sample-module tutorial_member```
